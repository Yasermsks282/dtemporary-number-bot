طريقة التشغيل:

1. ضع الملفات على جهازك في مجلد واحد.
2. ثبت PHP لديك، وشغّل الخادم المحلي (باستخدام XAMPP أو PHP Built-in Server).
3. اربط البوت بـ webhook عبر الرابط:

https://api.telegram.org/bot<توكن_البوت>/setWebhook?url=https://yourdomain.com/bot.php

4. يمكنك استخدام أوامر:
   /addchannel @channelusername

ليضيف البوت قناة اشتراك إجباري.

5. لم يتم تضمين كود سحب الأرقام من الموقع مؤقتًا، سأرسله في خطوة لاحقة لتكامل البوت بشكل آمن.