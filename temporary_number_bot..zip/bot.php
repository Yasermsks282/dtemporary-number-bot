<?php
define('API_KEY', '8121608942:AAE2pmnJnPNw2KNhiDYnie78EfMfNRWujj8');
define('ADMIN_ID', 'YOUR_TELEGRAM_ID'); // ضع معرفك هنا كأدمن

function bot($method, $data = []) {
    $url = "https://api.telegram.org/bot" . API_KEY . "/$method";
    $options = [
        "http" => [
            "method" => "POST",
            "header" => "Content-Type:application/x-www-form-urlencoded",
            "content" => http_build_query($data),
        ],
    ];
    $context = stream_context_create($options);
    return json_decode(file_get_contents($url, false, $context), true);
}

function sendMessage($chat_id, $text, $keyboard = null) {
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($keyboard) {
        $data['reply_markup'] = json_encode(['inline_keyboard' => $keyboard]);
    }
    bot('sendMessage', $data);
}

function isUserSubscribed($user_id) {
    $channels = json_decode(file_get_contents("settings.json"), true)['channels'];
    foreach ($channels as $channel) {
        $res = bot('getChatMember', ['chat_id' => $channel, 'user_id' => $user_id]);
        if (!isset($res['result']['status']) || in_array($res['result']['status'], ['left', 'kicked'])) {
            return false;
        }
    }
    return true;
}

function saveUser($user_id, $data) {
    $users = file_exists("users.json") ? json_decode(file_get_contents("users.json"), true) : [];
    $users[$user_id] = $data;
    file_put_contents("users.json", json_encode($users));
}

$update = json_decode(file_get_contents("php://input"), true);
$message = $update["message"] ?? $update["callback_query"]["message"];
$chat_id = $message["chat"]["id"];
$text = $message["text"] ?? "";
$user_id = $message["from"]["id"];
$callback_data = $update["callback_query"]["data"] ?? null;

if (!$callback_data && !isUserSubscribed($user_id)) {
    $channels = json_decode(file_get_contents("settings.json"), true)['channels'];
    $buttons = [];
    foreach ($channels as $ch) {
        $buttons[] = [['text' => "انضم إلى $ch", 'url' => "https://t.me/$ch"]];
    }
    $buttons[] = [['text' => "تحقق ✅", 'callback_data' => "check_sub"]];
    sendMessage($chat_id, "🔒 يجب عليك الاشتراك في القنوات التالية:", $buttons);
    exit;
}

if ($text == "/start") {
    sendMessage($chat_id, "👋 أهلاً بك في بوت الأرقام المؤقتة.
اختر من الأزرار:", [
        [['text' => "📱 رقم جديد", 'callback_data' => "new_number"]],
        [['text' => "🌍 تغيير الدولة", 'callback_data' => "change_country"]]
    ]);
} elseif ($text == "/addchannel" && $user_id == ADMIN_ID) {
    $expl = explode(" ", $text);
    if (isset($expl[1])) {
        $settings = json_decode(file_get_contents("settings.json"), true);
        $settings['channels'][] = $expl[1];
        file_put_contents("settings.json", json_encode($settings));
        sendMessage($chat_id, "✅ تم إضافة القناة: " . $expl[1]);
    }
} elseif ($callback_data == "check_sub") {
    if (isUserSubscribed($user_id)) {
        sendMessage($chat_id, "✅ تم التحقق من الاشتراك بنجاح.");
    } else {
        sendMessage($chat_id, "❌ لم يتم الاشتراك في جميع القنوات.");
    }
}

// ملاحظة: ستحتاج لإضافة كود جلب الأرقام هنا من الموقع + منطق إدارة الدولة والرقم الحالي.

?>